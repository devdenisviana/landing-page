# ballecoffee
![CapaBallecoffee](https://github.com/HakaCode/ballecoffee/assets/33907565/cc1b5575-c35c-4ea9-8b4c-5bb6f3adea69)

## Links
[![YouTube](https://img.shields.io/badge/YouTube-%23FF0000.svg?style=for-the-badge&logo=YouTube&logoColor=white)](https://www.youtube.com/watch?v=Lx_YsoMgP40&ab_channel=RafaellaBallerini) ° [![Figma](https://img.shields.io/badge/figma-%23F24E1E.svg?style=for-the-badge&logo=figma&logoColor=white)](https://www.figma.com/community/file/1313634245991275530) ° [![Discord](https://img.shields.io/badge/Discord-%235865F2.svg?style=for-the-badge&logo=discord&logoColor=white)](https://discord.gg/wagxzStdcR) 
